/**
 * Help Content Manager
 * Manages help topics, command documentation, and content search
 */

import { logger } from '../../utils/logger';
import type { 
  CommandInfo, 
  IHelpContentManager 
} from '../interfaces/HelpSystemInterfaces';

export interface HelpTopic {
  title: string;
  description: string;
  sections: HelpSection[];
  relatedCommands?: string[];
  examples?: string[];
}

export interface HelpSection {
  title: string;
  content: string;
  code?: string;
}

export interface CommandHelp {
  name: string;
  description: string;
  usage: string;
  examples: string[];
  parameters?: ParameterHelp[];
  permissions?: string;
  aliases?: string[];
  relatedCommands?: string[];
}

export interface ParameterHelp {
  name: string;
  description: string;
  type: string;
  required: boolean;
  choices?: string[];
  example?: string;
}

export interface SearchResult {
  type: 'topic' | 'command';
  name: string;
  relevance: number;
}

export class HelpContentManager implements IHelpContentManager {
  private helpTopics: Map<string, HelpTopic> = new Map();
  private commandHelp: Map<string, CommandHelp> = new Map();

  constructor() {
    this.initializeHelpTopics();
    this.initializeCommandHelp();
  }

  private initializeHelpTopics(): void {
    // Getting Started Topic
    this.helpTopics.set('getting-started', {
      title: '🚀 Getting Started with TroutLLM Bot',
      description: 'Learn the basics of using TroutLLM and its features',
      sections: [
        {
          title: 'Basic Chat',
          content: 'Start chatting with the bot using `/chat` command or by mentioning the bot directly.',
          code: '/chat message:Hello, how are you today?'
        },
        {
          title: 'Setting Personality',
          content: 'The bot has dual personalities: roasting and helpful. You can set your preference.',
          code: '/preferences set key:defaultPersonality value:helpful'
        },
        {
          title: 'Command History',
          content: 'The bot tracks your command history for easy replay and reference.',
          code: '/history view limit:10'
        },
        {
          title: 'Getting Help',
          content: 'Use the help command to get information about specific commands or topics.',
          code: '/help command:preferences'
        }
      ],
      relatedCommands: ['chat', 'preferences', 'help', 'status'],
      examples: [
        'Try: `/chat message:Tell me a joke`',
        'Set up: `/preferences set key:commandHistory value:true`',
        'Explore: `/help topic:personality`'
      ]
    });

    // Personality System Topic
    this.helpTopics.set('personality', {
      title: '🎭 Personality System',
      description: 'Understanding dual personalities and roasting behavior',
      sections: [
        {
          title: 'Dual Personalities',
          content: 'TroutLLM has two personalities: **Roasting** (sarcastic, witty) and **Helpful** (supportive, informative). The bot dynamically switches between them based on probability and context.'
        },
        {
          title: 'Roasting Behavior',
          content: 'The roasting system uses sophisticated algorithms including chaos mode, psychological warfare, and contextual intelligence to create entertaining interactions.'
        },
        {
          title: 'User Personality Profiles',
          content: 'You can set personality traits about yourself or others that the bot will remember and reference.',
          code: '/mypersonality description:Loves coffee and coding'
        },
        {
          title: 'Managing Personalities',
          content: 'View, add, or remove personality descriptions for yourself or others (admin permissions required for others).',
          code: '/getpersonality user:@username'
        }
      ],
      relatedCommands: ['setpersonality', 'mypersonality', 'getpersonality', 'removepersonality', 'clearpersonality'],
      examples: [
        'Add trait: `/mypersonality description:Terrible at math but great at debugging`',
        'View profile: `/getpersonality`',
        'Remove trait: `/removepersonality description:Terrible at math but great at debugging`'
      ]
    });

    // Command Aliases Topic
    this.helpTopics.set('aliases', {
      title: '⚡ Command Aliases',
      description: 'Create shortcuts for frequently used commands',
      sections: [
        {
          title: 'What are Aliases?',
          content: 'Aliases are custom shortcuts for commands. Instead of typing `/chat message:Hello`, you could create an alias `hi` that does the same thing.'
        },
        {
          title: 'Creating Aliases',
          content: 'Use the alias command to create shortcuts for any command.',
          code: '/alias add alias:hi command:chat message:Hello there!'
        },
        {
          title: 'Using Aliases',
          content: 'Once created, aliases work just like regular commands. They support autocomplete and appear in your command suggestions.'
        },
        {
          title: 'Managing Aliases',
          content: 'View all your aliases or remove ones you no longer need.',
          code: '/alias list'
        }
      ],
      relatedCommands: ['alias'],
      examples: [
        'Quick chat: `/alias add alias:q command:chat`',
        'Status check: `/alias add alias:s command:status`',
        'View aliases: `/alias list`',
        'Remove alias: `/alias remove alias:q`'
      ]
    });

    // Add remaining topics...
    this.initializeRemainingTopics();
  }

  private initializeRemainingTopics(): void {
    // Scheduled Commands Topic
    this.helpTopics.set('scheduling', {
      title: '⏰ Scheduled Commands',
      description: 'Execute commands at specific times or on recurring schedules',
      sections: [
        {
          title: 'Scheduling Commands',
          content: 'Schedule any command to execute in the future. Supports relative time (2h, 30m) and recurring schedules.',
          code: '/schedule add command:status time:2h recurring:daily'
        },
        {
          title: 'Time Formats',
          content: 'Supported formats: "2h" (2 hours), "30m" (30 minutes), "tomorrow 9am", "next Friday"'
        },
        {
          title: 'Recurring Schedules',
          content: 'Set commands to repeat daily, weekly, or monthly. Perfect for regular status checks or reminders.'
        },
        {
          title: 'Managing Scheduled Commands',
          content: 'View all your scheduled commands and remove ones you no longer need.',
          code: '/schedule list'
        }
      ],
      relatedCommands: ['schedule'],
      examples: [
        'Daily status: `/schedule add command:status time:9am recurring:daily`',
        'Weekly health check: `/schedule add command:health time:"Monday 10am" recurring:weekly`',
        'One-time reminder: `/schedule add command:chat message:"Remember the meeting!" time:1h`'
      ]
    });

    // Bulk Operations Topic
    this.helpTopics.set('bulk', {
      title: '📦 Bulk Operations',
      description: 'Execute multiple commands efficiently in batch',
      sections: [
        {
          title: 'What are Bulk Operations?',
          content: 'Bulk operations allow you to execute multiple commands in sequence, with progress tracking and error handling.'
        },
        {
          title: 'Creating Bulk Operations',
          content: 'Provide a JSON array of commands to execute. Each command runs independently.',
          code: '/bulk create commands:[{"command":"status","arguments":{}},{"command":"health","arguments":{"timeframe":"1h"}}]'
        },
        {
          title: 'Monitoring Progress',
          content: 'Check the status of your bulk operations to see progress and results.',
          code: '/bulk status operation_id:bulk-1234567890'
        },
        {
          title: 'Best Practices',
          content: 'Keep bulk operations reasonable in size (under 20 commands). Commands run sequentially to avoid rate limits.'
        }
      ],
      relatedCommands: ['bulk'],
      examples: [
        'Multiple status checks: `[{"command":"status"},{"command":"health"},{"command":"contextstats"}]`',
        'Personality cleanup: `[{"command":"clearpersonality"},{"command":"clear"}]`'
      ]
    });

    // User Preferences Topic
    this.helpTopics.set('preferences', {
      title: '⚙️ User Preferences',
      description: 'Customize your bot experience with personal settings',
      sections: [
        {
          title: 'Available Preferences',
          content: 'Customize personality, response style, features, timezone, and more.'
        },
        {
          title: 'Setting Preferences',
          content: 'Use the preferences command to modify your settings.',
          code: '/preferences set key:preferredResponseStyle value:technical'
        },
        {
          title: 'Privacy Controls',
          content: 'Control command history tracking, notifications, and data retention.',
          code: '/preferences set key:commandHistory value:false'
        },
        {
          title: 'Viewing Settings',
          content: 'See all your current preferences and when they were last updated.',
          code: '/preferences view'
        }
      ],
      relatedCommands: ['preferences'],
      examples: [
        'Enable code execution: `/preferences set key:enableCodeExecution value:true`',
        'Set timezone: `/preferences set key:timezone value:America/New_York`',
        'Response style: `/preferences set key:preferredResponseStyle value:concise`'
      ]
    });

    // Context Memory Topic
    this.helpTopics.set('context', {
      title: '🧠 Context Memory',
      description: 'Understanding how the bot remembers conversations and context',
      sections: [
        {
          title: 'Conversation Memory',
          content: 'The bot maintains conversation history per user, with configurable retention and automatic cleanup.'
        },
        {
          title: 'Server Context',
          content: 'Server-wide memory includes embarrassing moments, running gags, and shared context between users.'
        },
        {
          title: 'Memory Management',
          content: 'Context is automatically compressed and optimized to maintain performance while preserving important information.'
        },
        {
          title: 'Privacy & Control',
          content: 'You can clear your conversation history, disable memory features, or manage server context (admin only).',
          code: '/clear'
        }
      ],
      relatedCommands: ['clear', 'remember', 'addgag', 'contextstats', 'summarize', 'deduplicate'],
      examples: [
        'Clear history: `/clear`',
        'Add embarrassing moment: `/remember user:@someone moment:Forgot their own birthday`',
        'Add running gag: `/addgag gag:Always mentions cats in technical discussions`',
        'View stats: `/contextstats`'
      ]
    });

    // Code Execution Topic
    this.helpTopics.set('code', {
      title: '💻 Code Execution',
      description: 'Running Python code and solving math problems',
      sections: [
        {
          title: 'Code Execution Feature',
          content: 'When enabled, the bot can execute Python code and solve mathematical problems safely.'
        },
        {
          title: 'Enabling Code Execution',
          content: 'Enable this feature in your preferences or through environment configuration.',
          code: '/preferences set key:enableCodeExecution value:true'
        },
        {
          title: 'Using Code Execution',
          content: 'Use the execute command to run Python code or solve math problems.',
          code: '/execute code:print("Hello, World!")'
        },
        {
          title: 'Safety & Limitations',
          content: 'Code execution runs in a sandboxed environment with time and resource limits for security.'
        }
      ],
      relatedCommands: ['execute', 'preferences'],
      examples: [
        'Math problem: `/execute code:import math; print(math.sqrt(144))`',
        'Data analysis: `/execute code:data = [1,2,3,4,5]; print(f"Average: {sum(data)/len(data)}")`',
        'Algorithm: `/execute code:def fibonacci(n): return n if n <= 1 else fibonacci(n-1) + fibonacci(n-2); print(fibonacci(10))`'
      ]
    });

    // Video Processing Topic
    this.helpTopics.set('video', {
      title: '🎥 Video Processing',
      description: 'Analyzing video files and YouTube content with AI',
      sections: [
        {
          title: 'Video Analysis Capabilities',
          content: 'The bot can analyze video content, describe scenes, identify objects, transcribe audio, and answer questions about video content. Video processing is disabled by default due to high token costs.'
        },
        {
          title: 'Supported Formats',
          content: 'Supported video formats: MP4, MOV, AVI, WebM. Maximum file size: 20MB. Maximum duration: 3 minutes (180 seconds).',
          code: 'Upload video files directly as Discord attachments'
        },
        {
          title: 'YouTube URL Support',
          content: 'When enabled, you can analyze YouTube videos by providing URLs. The bot will process the video content directly.',
          code: '@TroutLLM analyze this video: https://youtube.com/watch?v=VIDEO_ID'
        },
        {
          title: 'Token Cost & Confirmation',
          content: 'Video processing uses 10-50x more tokens than text. You will see a cost estimate and confirmation prompt before processing begins.',
          code: 'Example: "This 2-minute video will use ~15,000 tokens and take ~2 minutes to process. Continue?"'
        },
        {
          title: 'Processing Time',
          content: 'Video analysis takes time - typically 30 seconds to 3 minutes depending on video length. You\'ll see progress updates during processing.'
        },
        {
          title: 'Enabling Video Support',
          content: 'Video processing is disabled by default. Server administrators can enable it through environment configuration.',
          code: 'Environment: VIDEO_SUPPORT_ENABLED=true'
        }
      ],
      relatedCommands: ['chat', 'preferences'],
      examples: [
        'Video analysis: Upload a video file and ask "What happens in this video?"',
        'YouTube analysis: "@TroutLLM analyze https://youtube.com/watch?v=dQw4w9WgXcQ"',
        'Specific questions: "What objects do you see at the 1:30 mark?"',
        'Scene description: "Describe the main scenes in this video"',
        'Audio transcription: "What is being said in this video?"'
      ]
    });
  }

  private initializeCommandHelp(): void {
    // Core Commands
    this.commandHelp.set('chat', {
      name: 'chat',
      description: 'Have a conversation with TroutLLM',
      usage: '/chat message:<your message>',
      examples: [
        '/chat message:What\'s the weather like today?',
        '/chat message:Explain quantum computing in simple terms',
        '/chat message:Tell me a programming joke'
      ],
      parameters: [
        {
          name: 'message',
          description: 'Your message to the AI',
          type: 'string',
          required: true,
          example: 'Hello, how are you?'
        }
      ],
      relatedCommands: ['preferences', 'status', 'clear']
    });

    this.commandHelp.set('preferences', {
      name: 'preferences',
      description: 'Manage your personal settings and preferences',
      usage: '/preferences <view|set|reset>',
      examples: [
        '/preferences view',
        '/preferences set key:defaultPersonality value:helpful',
        '/preferences reset'
      ],
      parameters: [
        {
          name: 'key',
          description: 'The preference to modify',
          type: 'choice',
          required: true,
          choices: ['defaultPersonality', 'preferredResponseStyle', 'enableCodeExecution', 'timezone'],
          example: 'defaultPersonality'
        },
        {
          name: 'value',
          description: 'The value to set',
          type: 'string',
          required: true,
          example: 'helpful'
        }
      ],
      relatedCommands: ['chat', 'alias', 'history']
    });

    // Initialize remaining commands...
    this.initializeRemainingCommands();
  }

  private initializeRemainingCommands(): void {
    // Additional command initializations
    
    this.commandHelp.set('alias', {
      name: 'alias',
      description: 'Create and manage command shortcuts',
      usage: '/alias <list|add|remove>',
      examples: [
        '/alias list',
        '/alias add alias:hi command:chat message:Hello!',
        '/alias remove alias:hi'
      ],
      parameters: [
        {
          name: 'alias',
          description: 'The shortcut name',
          type: 'string',
          required: true,
          example: 'hi'
        },
        {
          name: 'command',
          description: 'The full command to execute',
          type: 'string',
          required: true,
          example: 'chat message:Hello there!'
        }
      ],
      relatedCommands: ['preferences', 'help']
    });

    this.commandHelp.set('history', {
      name: 'history',
      description: 'View and manage your command history',
      usage: '/history <view|replay|clear>',
      examples: [
        '/history view limit:10',
        '/history replay command_id:cmd-1234567890',
        '/history clear'
      ],
      parameters: [
        {
          name: 'limit',
          description: 'Number of commands to show',
          type: 'integer',
          required: false,
          example: '10'
        },
        {
          name: 'command_id',
          description: 'ID of command to replay',
          type: 'string',
          required: true,
          example: 'cmd-1234567890'
        }
      ],
      relatedCommands: ['preferences', 'alias']
    });

    this.commandHelp.set('schedule', {
      name: 'schedule',
      description: 'Schedule commands for future execution',
      usage: '/schedule <add|list|remove>',
      examples: [
        '/schedule add command:status time:2h',
        '/schedule add command:health time:"tomorrow 9am" recurring:daily',
        '/schedule list'
      ],
      parameters: [
        {
          name: 'command',
          description: 'Command to schedule',
          type: 'string',
          required: true,
          example: 'status'
        },
        {
          name: 'time',
          description: 'When to execute',
          type: 'string',
          required: true,
          example: '2h'
        },
        {
          name: 'recurring',
          description: 'Repeat schedule',
          type: 'choice',
          required: false,
          choices: ['none', 'daily', 'weekly', 'monthly'],
          example: 'daily'
        }
      ],
      relatedCommands: ['preferences', 'bulk']
    });

    this.commandHelp.set('bulk', {
      name: 'bulk',
      description: 'Execute multiple commands in batch',
      usage: '/bulk <create|status|cancel>',
      examples: [
        '/bulk create commands:[{"command":"status"},{"command":"health"}]',
        '/bulk status operation_id:bulk-1234567890'
      ],
      parameters: [
        {
          name: 'commands',
          description: 'JSON array of commands to execute',
          type: 'string',
          required: true,
          example: '[{"command":"status","arguments":{}}]'
        },
        {
          name: 'operation_id',
          description: 'ID of bulk operation',
          type: 'string',
          required: true,
          example: 'bulk-1234567890'
        }
      ],
      relatedCommands: ['schedule', 'history']
    });

    this.commandHelp.set('help', {
      name: 'help',
      description: 'Get help and usage examples',
      usage: '/help [command] [topic]',
      examples: [
        '/help',
        '/help command:preferences',
        '/help topic:getting-started'
      ],
      parameters: [
        {
          name: 'command',
          description: 'Get help for specific command',
          type: 'string',
          required: false,
          example: 'preferences'
        },
        {
          name: 'topic',
          description: 'Get help on specific topic',
          type: 'choice',
          required: false,
          choices: ['getting-started', 'personality', 'aliases', 'scheduling', 'bulk', 'preferences', 'context', 'code', 'video'],
          example: 'getting-started'
        }
      ],
      relatedCommands: ['preferences', 'alias', 'history']
    });

    // Add some core commands that exist
    this.commandHelp.set('status', {
      name: 'status',
      description: 'Check bot status and remaining API quota',
      usage: '/status',
      examples: ['/status'],
      parameters: [],
      relatedCommands: ['health', 'chat']
    });

    this.commandHelp.set('clear', {
      name: 'clear',
      description: 'Clear your conversation history with the bot',
      usage: '/clear',
      examples: ['/clear'],
      parameters: [],
      relatedCommands: ['chat', 'contextstats']
    });
  }

  getHelpTopic(topicId: string): HelpTopic | null {
    return this.helpTopics.get(topicId) || null;
  }

  getCommandHelp(commandName: string): CommandInfo | null {
    const help = this.commandHelp.get(commandName);
    if (!help) return null;
    
    // Convert CommandHelp to CommandInfo
    return {
      name: help.name,
      description: help.description,
      usage: help.usage,
      examples: help.examples,
      permissions: help.permissions === 'Admin required' ? 'admin' : 
        help.permissions === 'Moderator required' ? 'moderator' : 'all',
      cooldown: 0, // Default cooldown
      aliases: help.aliases
    };
  }

  getAllTopics(): string[] {
    return Array.from(this.helpTopics.keys());
  }

  getAllCommands(): string[] {
    return Array.from(this.commandHelp.keys());
  }

  searchHelp(query: string): SearchResult[] {
    const results: SearchResult[] = [];
    const lowercaseQuery = query.toLowerCase();

    // Search topics
    for (const [topicId, topic] of this.helpTopics) {
      let relevance = 0;
      
      if (topic.title.toLowerCase().includes(lowercaseQuery)) relevance += 10;
      if (topic.description.toLowerCase().includes(lowercaseQuery)) relevance += 5;
      
      topic.sections.forEach(section => {
        if (section.title.toLowerCase().includes(lowercaseQuery)) relevance += 3;
        if (section.content.toLowerCase().includes(lowercaseQuery)) relevance += 1;
      });

      if (relevance > 0) {
        results.push({ type: 'topic', name: topicId, relevance });
      }
    }

    // Search commands
    for (const [commandName, command] of this.commandHelp) {
      let relevance = 0;
      
      if (command.name.toLowerCase().includes(lowercaseQuery)) relevance += 15;
      if (command.description.toLowerCase().includes(lowercaseQuery)) relevance += 5;
      
      command.examples.forEach(example => {
        if (example.toLowerCase().includes(lowercaseQuery)) relevance += 2;
      });

      if (relevance > 0) {
        results.push({ type: 'command', name: commandName, relevance });
      }
    }

    return results.sort((a, b) => b.relevance - a.relevance).slice(0, 10);
  }

  /**
   * Get raw command help data for builder
   */
  getCommandHelpRaw(commandName: string): CommandHelp | null {
    return this.commandHelp.get(commandName) || null;
  }
}