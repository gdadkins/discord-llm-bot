export {};
//# sourceMappingURL=setup.d.ts.map