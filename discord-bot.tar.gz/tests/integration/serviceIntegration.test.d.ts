export {};
//# sourceMappingURL=serviceIntegration.test.d.ts.map