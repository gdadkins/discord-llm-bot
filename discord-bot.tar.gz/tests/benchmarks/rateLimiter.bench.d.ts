export declare function runRateLimiterBenchmarks(): Promise<import("./base").BenchmarkResult[]>;
//# sourceMappingURL=rateLimiter.bench.d.ts.map