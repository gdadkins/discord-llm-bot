export declare function runMessageSplitterBenchmarks(): Promise<import("./base").BenchmarkResult[]>;
//# sourceMappingURL=messageSplitter.bench.d.ts.map