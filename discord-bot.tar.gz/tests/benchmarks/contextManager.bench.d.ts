export declare function runContextManagerBenchmarks(): Promise<import("./base").BenchmarkResult[]>;
//# sourceMappingURL=contextManager.bench.d.ts.map