export declare function runRoastProbabilityBenchmarks(): Promise<import("./base").BenchmarkResult[]>;
//# sourceMappingURL=roastProbability.bench.d.ts.map