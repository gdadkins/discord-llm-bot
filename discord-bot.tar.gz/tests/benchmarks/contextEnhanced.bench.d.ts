export declare function runEnhancedContextBenchmarks(): Promise<import("./base").BenchmarkResult[]>;
//# sourceMappingURL=contextEnhanced.bench.d.ts.map