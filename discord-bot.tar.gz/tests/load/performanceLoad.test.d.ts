export {};
//# sourceMappingURL=performanceLoad.test.d.ts.map