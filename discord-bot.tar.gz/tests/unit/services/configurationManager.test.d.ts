export {};
//# sourceMappingURL=configurationManager.test.d.ts.map