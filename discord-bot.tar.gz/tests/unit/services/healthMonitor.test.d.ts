export {};
//# sourceMappingURL=healthMonitor.test.d.ts.map