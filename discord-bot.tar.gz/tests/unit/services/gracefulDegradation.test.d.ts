export {};
//# sourceMappingURL=gracefulDegradation.test.d.ts.map